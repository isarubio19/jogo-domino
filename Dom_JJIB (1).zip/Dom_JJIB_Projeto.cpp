/*Nomes: Beatriz Lopes Rizzo, Julia Gachido Schmidt, Joao Pedro Figols Neco e Isabella Rubio Venancio
Dom_JJIB_Projeto.cpp*/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "Dom_JJIB_Model.cpp"
#include "Dom_JJIB_Controller.cpp"

//inicializacao geral do jogo
main()
{
	inicializaMenu();
}
