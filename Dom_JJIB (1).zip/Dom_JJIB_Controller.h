/*Nomes: Beatriz Lopes Rizzo, Julia Gachido Schmidt, Joao Pedro Figols Neco e Isabella Rubio Venancio
Dom_JJIB_Controller.h*/

//prototipos das funcoes do controller
void geraPecas();
void embaralhaPecas();
void inicializaMenu();
void iniciaJogo();
void iniciaMenuJog();
void inicializaMenuFinal();
void jogar();
void fcase1_Jogar();
void fcase2_Comprar();
void fcase3_Passar(int pecasCompradas);
void jogadamesaDir();
void mudaLado();
void jogadaEsquerda();
void jogadamesaEsq();
void verificaPeca();
void trocaTurno();
int ganhaJogoLouvor();
int ganhaJogo2();
int verificaMao();
void zeraVariaveis();
void ganhador();
void contPecaBot();
void salvaJogo();
void recuperaJogo();
int verificaBot();
void jogarBot();
void compraBot();




