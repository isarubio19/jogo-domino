/*Nomes: Beatriz Lopes Rizzo, Julia Gachido Schmidt, Joao Pedro Figols Neco e Isabella Rubio Venancio
Dom_JJIB_View.h*/

//prototipos das funcoes do view
int menuGeral();
void apresentaPecas();
int menuJogador();
void apresentaMesa();
int escolherPeca();
char escolhaLadoMesa();
void mensagem (int msg);
void flush_in();
void regrasJogo();

